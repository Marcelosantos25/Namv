# Namorada Virtual - Aplicativo Android

Este diretório contém os arquivos necessários para gerar o APK do aplicativo Namorada Virtual.

## Pré-requisitos

Para gerar o APK, você precisará:

1. Node.js e npm instalados
2. Android Studio instalado
3. Android SDK configurado
4. JDK 11 ou superior

## Configuração

1. Certifique-se de que o servidor Flask esteja rodando em seu computador
2. Note o endereço IP do seu computador na rede local (pode ser encontrado com `ipconfig` ou `ifconfig`)

## Passos para gerar o APK

1. Navegue até esta pasta no terminal:
   ```
   cd mobile-app
   ```

2. Instale as dependências necessárias:
   ```
   npm install
   ```

3. Adicione a plataforma Android ao projeto:
   ```
   npm run cap:add:android
   ```

4. Sincronize as alterações com o projeto Android:
   ```
   npm run cap:sync
   ```

5. Abra o projeto no Android Studio:
   ```
   npm run cap:open:android
   ```

6. No Android Studio, faça o seguinte:
   - Vá para Build > Build Bundle(s) / APK(s) > Build APK(s)
   - Aguarde a compilação ser concluída
   - O APK será gerado em: `android/app/build/outputs/apk/debug/app-debug.apk`

7. Instale o APK em seu dispositivo Android:
   - Transfira o arquivo APK para seu dispositivo
   - No dispositivo, toque no arquivo APK para instalá-lo
   - Aceite as permissões solicitadas

## Uso do aplicativo

1. Ao abrir o aplicativo pela primeira vez, você precisará configurar o endereço do servidor:
   - Digite o endereço IP do seu computador onde o servidor Flask está rodando
   - Se estiver usando um emulador, pode usar `10.0.2.2` para se conectar ao localhost do seu computador

2. O aplicativo se conectará ao servidor e carregará os dados da Namorada Virtual

3. Você pode usar todas as funcionalidades:
   - Conversar com a Namorada Virtual
   - Ajustar configurações de personalidade
   - Ver e limpar o histórico de conversa

## Observações

- O aplicativo requer que você e seu dispositivo móvel estejam na mesma rede Wi-Fi
- O servidor precisa estar rodando para que o aplicativo funcione
- Os dados são armazenados localmente no servidor, não no dispositivo móvel