# Instruções para Construir o APK do Aplicativo Namorada Virtual

Este guia explica como gerar um APK instalável do aplicativo Namorada Virtual em seu próprio computador.

## Requisitos

1. **Android Studio** - [Download do Android Studio](https://developer.android.com/studio)
2. **JDK 11 ou superior** - Instalado com o Android Studio ou separadamente

## Passos para Construir o APK

### 1. Clone o repositório e configure o ambiente

1. Faça o download do código-fonte do projeto
2. Certifique-se de ter o Node.js instalado (versão 14.x ou superior)
3. Abra um terminal na pasta `mobile-app`
4. Execute `npm install` para instalar todas as dependências

### 2. Sincronize e prepare o projeto para Android

```bash
npm run cap:sync
```

### 3. Abra o projeto no Android Studio

```bash
npm run cap:open:android
```

Ou abra manualmente a pasta `mobile-app/android` no Android Studio.

### 4. Construa o APK

No Android Studio:
1. Selecione "Build" > "Build Bundle(s) / APK(s)" > "Build APK(s)"
2. Aguarde a compilação terminar
3. Clique em "locate" quando aparecer a notificação de "APK generated successfully"

O APK será gerado em: `mobile-app/android/app/build/outputs/apk/debug/app-debug.apk`

### 5. Instalar o APK no dispositivo Android

1. Transfira o APK para seu dispositivo Android (via USB, e-mail, etc.)
2. No dispositivo Android, navegue até o arquivo APK e toque nele
3. Siga as instruções para instalar (pode ser necessário permitir a instalação de aplicativos de fontes desconhecidas)

## Compatibilidade

Este aplicativo é compatível com dispositivos Android 11 (API nível 30) ou superior.

## Funcionalidades Offline

O aplicativo Namorada Virtual funciona completamente offline:
- Todas as conversas são armazenadas localmente
- Configurações de personalidade são salvas no dispositivo
- Não requer conexão com internet ou servidor externo

## Solução de Problemas

### Se o APK não instalar:
- Verifique se seu dispositivo permite a instalação de aplicativos de fontes desconhecidas
- Certifique-se de que seu dispositivo execute Android 11 ou superior
- Tente reiniciar o dispositivo e instalar novamente

### Se o aplicativo fechar inesperadamente:
- Verifique as permissões do aplicativo nas configurações do dispositivo
- Certifique-se de que as permissões de armazenamento estão habilitadas