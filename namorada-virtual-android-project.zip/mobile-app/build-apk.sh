#!/bin/bash

echo "====== Compilando APK da Namorada Virtual ======"
echo ""
echo "Este script vai compilar o APK do aplicativo."
echo "Certifique-se de ter o Android Studio e o JDK instalados."
echo ""

cd android
./gradlew assembleDebug

if [ $? -eq 0 ]; then
    echo ""
    echo "====== Compilação Concluída com Sucesso! ======"
    echo ""
    echo "O APK foi gerado em:"
    echo "android/app/build/outputs/apk/debug/app-debug.apk"
    echo ""
    echo "Copie este arquivo para seu dispositivo Android e instale-o."
else
    echo ""
    echo "====== Erro na Compilação ======"
    echo ""
    echo "Verifique se você tem o JDK instalado e configurado corretamente."
    echo "Tente abrir o projeto no Android Studio e compilar por lá."
fi

echo ""
echo "Pressione Enter para continuar..."
read