/**
 * Personality Service para o aplicativo móvel
 * Fornece funcionalidades para gerenciar a personalidade da namorada virtual
 * offline, utilizando o armazenamento local
 */

const PersonalityService = (function() {
    // Variáveis privadas
    const _localStorage = window.localStorage;
    const _personalityKey = 'namoradavirtual_personality';
    const _defaultPersonality = {
        name: 'Namorada Virtual',
        age: 25,
        affection: 7,
        humor: 6,
        chattiness: 7,
        sensitivity: 6,
        bio: 'Olá! Sou sua namorada virtual. Estou aqui para conversar e passar o tempo com você.',
        interests: ['música', 'filmes', 'viagens', 'conversas'],
        likes: ['chocolate', 'praia', 'carinho', 'música romântica'],
        dislikes: ['mentiras', 'grosseria', 'ficar longe de você'],
        profile_image: '',
        background_image: ''
    };
    
    /**
     * Salva os dados de personalidade no armazenamento local
     * @param {Object} personalityData - Dados de personalidade
     * @returns {boolean} Sucesso da operação
     */
    function savePersonality(personalityData) {
        try {
            // Mescla os dados com o padrão para garantir que todos os campos existam
            const mergedData = Object.assign({}, _defaultPersonality, personalityData);
            
            // Salva no localStorage
            _localStorage.setItem(_personalityKey, JSON.stringify(mergedData));
            
            // Se estiver disponível, também salva no SQLite
            if (window.SQLiteService && typeof window.SQLiteService.init === 'function') {
                _savePersonalityToSQLite(mergedData);
            }
            
            console.log("Personalidade salva localmente com sucesso");
            return true;
        } catch (error) {
            console.error("Erro ao salvar personalidade localmente:", error);
            return false;
        }
    }
    
    /**
     * Carrega os dados de personalidade do armazenamento local
     * @returns {Object|null} Dados de personalidade ou null
     */
    function loadPersonality() {
        try {
            // Tenta carregar do localStorage
            const storedData = _localStorage.getItem(_personalityKey);
            
            if (storedData) {
                return JSON.parse(storedData);
            }
            
            // Se não existir no localStorage, tenta carregar do SQLite
            if (window.SQLiteService && typeof window.SQLiteService.init === 'function') {
                return _loadPersonalityFromSQLite();
            }
            
            // Se não encontrar, retorna a personalidade padrão
            return _defaultPersonality;
        } catch (error) {
            console.error("Erro ao carregar personalidade localmente:", error);
            return _defaultPersonality;
        }
    }
    
    /**
     * Salva a personalidade no banco de dados SQLite
     * @param {Object} personalityData - Dados de personalidade
     * @private
     */
    async function _savePersonalityToSQLite(personalityData) {
        try {
            await window.SQLiteService.init();
            
            // Cria a tabela de personalidade se não existir
            const createTableQuery = `
            CREATE TABLE IF NOT EXISTS personality (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                data TEXT NOT NULL,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );`;
            
            await window.SQLiteService.executeQuery(createTableQuery);
            
            // Verifica se já existe um registro
            const checkQuery = "SELECT id FROM personality WHERE id = 1";
            const result = await window.SQLiteService.executeQuery(checkQuery);
            
            if (result.values && result.values.length > 0) {
                // Atualiza o registro existente
                const updateQuery = `
                UPDATE personality 
                SET data = ?, updated_at = CURRENT_TIMESTAMP 
                WHERE id = 1
                `;
                
                await window.SQLiteService.executeQuery(updateQuery, [
                    JSON.stringify(personalityData)
                ]);
            } else {
                // Insere um novo registro
                const insertQuery = `
                INSERT INTO personality (id, data) 
                VALUES (1, ?)
                `;
                
                await window.SQLiteService.executeQuery(insertQuery, [
                    JSON.stringify(personalityData)
                ]);
            }
            
            console.log("Personalidade salva no SQLite com sucesso");
        } catch (error) {
            console.error("Erro ao salvar personalidade no SQLite:", error);
        }
    }
    
    /**
     * Carrega a personalidade do banco de dados SQLite
     * @returns {Promise<Object|null>} - Dados de personalidade ou null
     * @private
     */
    async function _loadPersonalityFromSQLite() {
        try {
            await window.SQLiteService.init();
            
            const query = "SELECT data FROM personality WHERE id = 1";
            const result = await window.SQLiteService.executeQuery(query);
            
            if (result.values && result.values.length > 0) {
                const personalityData = JSON.parse(result.values[0].data);
                console.log("Personalidade carregada do SQLite com sucesso");
                return personalityData;
            }
            
            console.log("Nenhuma personalidade encontrada no SQLite");
            return null;
        } catch (error) {
            console.error("Erro ao carregar personalidade do SQLite:", error);
            return null;
        }
    }
    
    /**
     * Importa dados de personalidade do servidor
     * @param {string} serverURL - URL do servidor
     * @returns {Promise<Object|null>} - Dados de personalidade importados ou null
     */
    async function importFromServer(serverURL) {
        try {
            const response = await fetch(`${serverURL}/update_personality`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({}) // Enviamos vazio para obter a resposta com os dados atuais
            });
            
            const data = await response.json();
            
            if (data.personality) {
                // Salva a personalidade importada localmente
                savePersonality(data.personality);
                console.log("Personalidade importada do servidor com sucesso");
                return data.personality;
            }
            
            console.log("Nenhuma personalidade encontrada no servidor");
            return null;
        } catch (error) {
            console.error("Erro ao importar personalidade do servidor:", error);
            return null;
        }
    }
    
    // Interface pública
    return {
        savePersonality,
        loadPersonality,
        importFromServer,
        getDefaultPersonality: () => Object.assign({}, _defaultPersonality)
    };
})();

// Exporta para uso global
window.PersonalityService = PersonalityService;