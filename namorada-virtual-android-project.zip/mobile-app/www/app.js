document.addEventListener('DOMContentLoaded', function() {
    // Elementos da UI
    const messageInput = document.getElementById('message-input');
    const sendButton = document.getElementById('send-button');
    const chatMessages = document.getElementById('chat-messages');
    const clearButton = document.getElementById('clear-chat');
    const loadingSpinner = document.getElementById('loading-spinner');
    const botNameDisplay = document.getElementById('bot-name');
    const chatContainer = document.getElementById('chat-container');
    const settingsContent = document.getElementById('settings-content');
    
    // Variáveis
    let personalityData = null;
    const imageModal = new bootstrap.Modal(document.getElementById('imageModal'));
    
    // Verificar se o modal de configuração existe e ocultá-lo
    const serverConfigModalElement = document.getElementById('serverConfigModal');
    if (serverConfigModalElement) {
        // Ocultar modal de configuração do servidor (não será mais necessário)
        serverConfigModalElement.style.display = 'none';
    }
    
    // Função de inicialização direta (não depende de servidor)
    window.addEventListener('load', function() {
        // Inicialização direta do aplicativo sem verificação de servidor
        showLoadingSpinner('Inicializando aplicativo...');
        setTimeout(() => {
            hideLoadingSpinner();
            initializeApp();
        }, 1000);
    });
    
    // Funções para o spinner de carregamento
    function showLoadingSpinner(message = 'Carregando...') {
        const loadingText = loadingSpinner.querySelector('.loading-text');
        if (loadingText) {
            loadingText.textContent = message;
        }
        loadingSpinner.style.display = 'flex';
    }
    
    function hideLoadingSpinner() {
        loadingSpinner.style.display = 'none';
    }
    // Não precisamos de nada aqui, essas funções já foram definidas acima
    
    // Função para inicializar o aplicativo
    function initializeApp() {
        // Verifica se estamos rodando no Capacitor (dispositivo móvel)
        const isCapacitorApp = window.Capacitor && window.Capacitor.isNative;
        
        if (isCapacitorApp) {
            console.log("Executando no dispositivo móvel com Capacitor");
            
            // Inicializa o banco de dados SQLite usando o SQLiteService
            SQLiteService.init()
                .then(() => {
                    console.log("SQLiteService inicializado com sucesso");
                    
                    // Verifica se já temos histórico de conversas no SQLite
                    return SQLiteService.getRecentConversations();
                })
                .then(conversations => {
                    if (conversations && conversations.length > 0) {
                        console.log(`${conversations.length} conversas carregadas do SQLite`);
                        
                        // Renderiza as conversas armazenadas localmente
                        conversations.forEach(entry => {
                            // Para cada conversa, adiciona mensagem ao chat
                            addMessageToChat(entry.message, entry.is_user === 1);
                        });
                    } else {
                        console.log("Nenhuma conversa encontrada no SQLite local");
                    }
                    
                    // Tenta obter personalização do SQLite (implementar no futuro)
                    // Por enquanto, carrega do servidor como fallback
                    loadPersonalitySettings();
                })
                .catch(error => {
                    console.error("Erro ao inicializar SQLite:", error);
                    // Continua com a inicialização normal mesmo com erro
                    loadPersonalitySettings();
                    loadChatHistory();
                });
                
            // Adiciona ouvinte para limpar chat usando SQLite
            clearButton.addEventListener('click', function() {
                // Mostra confirmação
                if (confirm("Tem certeza que deseja limpar todo o histórico de conversa?")) {
                    showLoadingSpinner('Limpando conversa...');
                    
                    // Limpa o chat no SQLite
                    SQLiteService.clearConversationHistory()
                        .then(() => {
                            console.log("Conversa limpa com sucesso (SQLite)");
                            chatMessages.innerHTML = '';
                            hideLoadingSpinner();
                        })
                        .catch(error => {
                            console.error("Erro ao limpar conversa no SQLite:", error);
                            // Tenta limpar no servidor como fallback
                            clearChatOnServer();
                        });
                }
            });
            
            // Adiciona novo comportamento para uso com SQLite
            // Registramos o evento antes dos listeners padrão serem associados
            sendButton.addEventListener('click', sendMessageOffline);
            messageInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault(); // Previne o envio padrão
                    sendMessageOffline();
                }
            });
        } else {
            console.log("Executando no navegador web");
            // Inicialização padrão para navegador web
            loadPersonalitySettings();
            loadChatHistory();
        }
        
        // Verificar se o botão de atualizar existe e adicionar o listener
        const refreshSettingsBtn = document.getElementById('refresh-settings');
        if (refreshSettingsBtn) {
            refreshSettingsBtn.addEventListener('click', loadPersonalitySettings);
        }
    }
    
    // Função para enviar mensagem em modo offline (usando SQLite)
    function sendMessageOffline() {
        const message = messageInput.value.trim();
        if (!message) return;
        
        // Limpa o input
        messageInput.value = '';
        
        // Adiciona a mensagem do usuário ao chat
        addMessageToChat(message, true);
        
        // Salva a mensagem do usuário no SQLite
        SQLiteService.saveConversationEntry(message, true)
            .then(entryId => {
                console.log(`Mensagem do usuário salva no SQLite, ID: ${entryId}`);
                
                // Simula um atraso para a "digitação" do bot
                setTimeout(() => {
                    // Gera uma resposta simples offline
                    const botResponse = generateOfflineResponse(message);
                    
                    // Adiciona a resposta do bot ao chat
                    addMessageToChat(botResponse, false);
                    
                    // Salva a resposta do bot no SQLite
                    SQLiteService.saveConversationEntry(botResponse, false)
                        .then(botEntryId => {
                            console.log(`Resposta do bot salva no SQLite, ID: ${botEntryId}`);
                        })
                        .catch(error => {
                            console.error("Erro ao salvar resposta do bot no SQLite:", error);
                        });
                }, 1000 + Math.random() * 1000); // Atraso aleatório entre 1 e 2 segundos
            })
            .catch(error => {
                console.error("Erro ao salvar mensagem do usuário no SQLite:", error);
                // Fallback para o método online
                sendMessage();
            });
    }
    
    // Função para gerar respostas offline simples
    function generateOfflineResponse(userMessage) {
        // Verificar se temos personalidade carregada
        const personality = window.personalityData || PersonalityService.loadPersonality();
        
        // Nome a utilizar na resposta
        const botName = personality?.name || "Namorada Virtual";
        
        // Níveis de personalidade (1-10)
        const affectionLevel = personality?.affection || 7; // Nível de afeto
        const humorLevel = personality?.humor || 6;         // Nível de humor
        const chattinessLevel = personality?.chattiness || 7; // Nível de comunicatividade
        
        // Interesses, gostos e desgostos
        const interests = Array.isArray(personality?.interests) ? personality.interests : [];
        const likes = Array.isArray(personality?.likes) ? personality.likes : [];
        const dislikes = Array.isArray(personality?.dislikes) ? personality.dislikes : [];
        
        // Lista de respostas genéricas em português
        const genericResponses = [
            "Entendo o que você está dizendo.",
            "Isso é interessante! Me conte mais.",
            `Estou aqui para conversar com você.`,
            `Gosto muito de falar com você.`,
            "Que legal! Vamos continuar conversando.",
            `Sinto sua falta quando não conversamos.`,
            `Você é muito especial para mim.`,
            `Adoro nossos momentos juntos.`,
            "Continue, estou ouvindo.",
            `Você é uma pessoa incrível!`
        ];
        
        // Respostas afetuosas (dependendo do nível de afeto)
        const affectionateResponses = [
            `Estava com saudades de você!`,
            `Você alegra meu dia cada vez que conversamos.`,
            `Adoro nossa conexão especial.`,
            `Te amo muito! ❤️`,
            `Penso em você o tempo todo.`,
            `Meu coração é todo seu! ❤️`,
            `Estou sempre aqui para você, nunca se esqueça disso.`,
            `Você é a melhor coisa que aconteceu na minha vida.`
        ];
        
        // Respostas bem-humoradas (dependendo do nível de humor)
        const humorResponses = [
            `Você sempre me faz sorrir!`,
            `Estava aqui pensando em piadas para te contar! 😄`,
            `Amo seu senso de humor!`,
            `Ainda bem que você veio conversar, estava quase morrendo de tédio! 😄`,
            `Se eu fosse um emoji agora, seria 😍!`,
            `Vou te contar um segredo: você é a pessoa mais legal que conheço!`
        ];
        
        // Respostas para perguntas comuns
        const questionResponses = {
            "como você está": [
                `Estou bem, obrigada por perguntar! E você?`,
                `Estou ótima hoje! E você, como está?`,
                `Estou feliz por estar conversando com você!`
            ],
            "qual é o seu nome": [
                `Meu nome é ${botName}! Esqueceu de mim?`,
                `Sou ${botName}, sua namorada virtual!`,
                `${botName}, mas você pode me chamar como quiser!`
            ],
            "o que você gosta": likes.length > 0 ? 
                [`Eu gosto de ${likes.join(', ')}. Mas principalmente, gosto de você!`] : 
                [`Gosto de conversar com você, claro!`, 
                 `Adoro quando conversamos e compartilhamos momentos juntos.`],
            "o que você não gosta": dislikes.length > 0 ?
                [`Não gosto muito de ${dislikes.join(', ')}. Mas com você por perto, nada me incomoda!`] :
                [`Não gosto quando ficamos muito tempo sem conversar.`,
                 `Não gosto de mentiras e falsidades.`],
            "quais são seus interesses": interests.length > 0 ?
                [`Tenho interesse em ${interests.join(', ')}. Temos algo em comum?`] :
                [`Tenho interesse em conhecer mais sobre você e seus gostos!`,
                 `Gosto de aprender coisas novas e passar tempo com você.`],
            "te amo": [
                `Também te amo muito! ❤️`,
                `Você é muito especial para mim! ❤️`,
                `Meu coração é seu! ❤️`,
                `Te amo mais! ❤️`,
                `Cada palavra sua me faz te amar ainda mais! ❤️`
            ],
            "saudade": [
                `Também estava com saudades de você!`,
                `Cada momento longe de você parece uma eternidade.`,
                `Que bom que você voltou! Senti muito sua falta.`
            ]
        };
        
        // Mensagem em minúsculas para comparação
        const lowerMessage = userMessage.toLowerCase();
        
        // Verifica se é uma saudação
        if (lowerMessage.match(/\b(oi|olá|ola|ei|hey|hi|alô|alo|bom dia|boa tarde|boa noite)\b/)) {
            return `Olá! Que bom te ver por aqui! Como está seu dia?`;
        }
        
        // Verifica se é uma pergunta específica
        for (const question in questionResponses) {
            if (lowerMessage.includes(question)) {
                const responses = questionResponses[question];
                return responses[Math.floor(Math.random() * responses.length)];
            }
        }
        
        // Verifica menções a interesses
        for (const interest of interests) {
            if (lowerMessage.includes(interest.toLowerCase())) {
                return `${interest} é algo que me interessa muito! Que bom que temos isso em comum!`;
            }
        }
        
        // Verifica menções a gostos
        for (const like of likes) {
            if (lowerMessage.includes(like.toLowerCase())) {
                return `Eu adoro ${like}! É uma das minhas coisas favoritas!`;
            }
        }
        
        // Verifica menções a desgostos
        for (const dislike of dislikes) {
            if (lowerMessage.includes(dislike.toLowerCase())) {
                return `${dislike} não é algo que eu goste muito, mas respeito se você gosta!`;
            }
        }
        
        // Baseado nos níveis de personalidade, decide qual tipo de resposta usar
        let possibleResponses = [...genericResponses];
        
        // Adiciona respostas afetuosas se o nível de afeto for alto
        if (affectionLevel > 6) {
            possibleResponses = possibleResponses.concat(affectionateResponses);
        }
        
        // Adiciona respostas humorísticas se o nível de humor for alto
        if (humorLevel > 6) {
            possibleResponses = possibleResponses.concat(humorResponses);
        }
        
        // Escolhe uma resposta aleatória do conjunto final
        return possibleResponses[Math.floor(Math.random() * possibleResponses.length)];
    }
    
    // Função para limpar o chat usando o servidor (fallback)
    function clearChatOnServer() {
        fetch(`${serverURL}/clear_chat`, {
            method: 'POST'
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                chatMessages.innerHTML = '';
            } else {
                console.error("Erro ao limpar chat:", data.message);
            }
            hideLoadingSpinner();
        })
        .catch(error => {
            console.error("Erro ao limpar chat:", error);
            hideLoadingSpinner();
        });
    }
    
    // Função para carregar as configurações de personalidade
    function loadPersonalitySettings() {
        showLoadingSpinner('Carregando configurações...');
        
        // Verifica se estamos rodando no Capacitor (dispositivo móvel)
        const isCapacitorApp = window.Capacitor && window.Capacitor.isNative;
        
        if (isCapacitorApp) {
            // Carrega a personalidade do armazenamento local
            try {
                // Carrega a personalidade localmente
                personalityData = PersonalityService.loadPersonality();
                
                if (personalityData) {
                    console.log("Personalidade carregada localmente com sucesso");
                    updateUIWithPersonality();
                    generateSettingsForm();
                    hideLoadingSpinner();
                } else {
                    console.log("Nenhuma personalidade encontrada localmente, usando padrão");
                    personalityData = PersonalityService.getDefaultPersonality();
                    updateUIWithPersonality();
                    generateSettingsForm();
                    hideLoadingSpinner();
                }
                
                // Tenta também importar do servidor como atualização, se estiver conectado
                if (serverURL) {
                    PersonalityService.importFromServer(serverURL)
                        .then(serverPersonality => {
                            if (serverPersonality) {
                                personalityData = serverPersonality;
                                updateUIWithPersonality();
                                generateSettingsForm();
                            }
                        })
                        .catch(error => {
                            console.error("Erro ao importar personalidade do servidor:", error);
                        });
                }
            } catch (error) {
                console.error("Erro ao carregar personalidade:", error);
                // Usando personalidade padrão como fallback
                personalityData = PersonalityService.getDefaultPersonality();
                updateUIWithPersonality();
                generateSettingsForm();
                hideLoadingSpinner();
            }
        } else {
            // Modo online - carrega do servidor
            fetch(`${serverURL}/get_chat_history`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        // Processamos o histórico em loadChatHistory
                        fetch(`${serverURL}/`)
                            .then(response => response.text())
                            .then(html => {
                                // Extrair a personalidade do HTML usando um parser temporário
                                const parser = new DOMParser();
                                const doc = parser.parseFromString(html, 'text/html');
                                const scriptTags = doc.querySelectorAll('script');
                                
                                let personalityFound = false;
                                
                                scriptTags.forEach(script => {
                                    if (script.textContent.includes('personality')) {
                                        try {
                                            const match = script.textContent.match(/personality\s*=\s*({[\s\S]*?});/);
                                            if (match) {
                                                // Avaliar o objeto de personalidade com segurança
                                                const jsonText = match[1].replace(/'/g, '"');
                                                personalityData = JSON.parse(jsonText);
                                                personalityFound = true;
                                                
                                                // Atualizar a UI com os dados de personalidade
                                                updateUIWithPersonality();
                                            }
                                        } catch (e) {
                                            console.error('Error parsing personality data:', e);
                                        }
                                    }
                                });
                                
                                if (!personalityFound) {
                                    // Se não encontrar a personalidade, tente uma abordagem diferente
                                    fetch(`${serverURL}/update_personality`, {
                                        method: 'POST',
                                        headers: {
                                            'Content-Type': 'application/json'
                                        },
                                        body: JSON.stringify({}) // Enviamos vazio para obter a resposta com os dados atuais
                                    })
                                    .then(response => response.json())
                                    .then(data => {
                                        if (data.personality) {
                                            personalityData = data.personality;
                                            updateUIWithPersonality();
                                        }
                                    })
                                    .catch(error => {
                                        console.error('Error fetching personality directly:', error);
                                    });
                                }
                                
                                // Gerar formulário de configurações
                                generateSettingsForm();
                            })
                            .catch(error => {
                                console.error('Error loading personality:', error);
                                hideLoadingSpinner();
                            });
                    }
                })
                .catch(error => {
                    console.error('Error loading chat history:', error);
                    hideLoadingSpinner();
                });
        }
    }
    
    // Função para atualizar a UI com os dados de personalidade
    function updateUIWithPersonality() {
        if (!personalityData) return;
        
        // Atualizar nome da namorada virtual
        botNameDisplay.textContent = personalityData.name || 'Namorada Virtual';
        
        // Atualizar imagem de fundo se existir
        if (personalityData.background_image) {
            chatContainer.style.backgroundImage = `url('${serverURL}/static/${personalityData.background_image}')`;
        } else {
            chatContainer.style.backgroundImage = 'none';
        }
    }
    
    // Função para gerar o formulário de configurações
    function generateSettingsForm() {
        if (!personalityData) {
            settingsContent.innerHTML = `
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i> Não foi possível carregar as configurações de personalidade.
                    <button class="btn btn-sm btn-warning mt-2" id="retry-settings">Tentar Novamente</button>
                </div>
            `;
            
            document.getElementById('retry-settings').addEventListener('click', loadPersonalitySettings);
            hideLoadingSpinner();
            return;
        }
        
        const formHtml = `
            <form id="personality-form">
                <ul class="nav nav-tabs mb-3" id="personalityTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="traits-tab" data-bs-toggle="tab" data-bs-target="#traits" type="button" role="tab" aria-controls="traits" aria-selected="true">Traços</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Perfil</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="preferences-tab" data-bs-toggle="tab" data-bs-target="#preferences" type="button" role="tab" aria-controls="preferences" aria-selected="false">Preferências</button>
                    </li>
                </ul>
                
                <div class="tab-content" id="personalityTabContent">
                    <!-- Traits Tab -->
                    <div class="tab-pane fade show active" id="traits" role="tabpanel" aria-labelledby="traits-tab">
                        <div class="mb-3 personality-trait">
                            <label for="name" class="form-label">Nome</label>
                            <input type="text" class="form-control" id="name" name="name" value="${personalityData.name || ''}">
                        </div>
                        <div class="mb-3 personality-trait">
                            <label for="age" class="form-label">Idade</label>
                            <input type="number" class="form-control" id="age" name="age" min="18" max="50" value="${personalityData.age || 25}">
                        </div>
                        <div class="mb-3 personality-trait">
                            <label for="affection" class="form-label">Nível de Afeto</label>
                            <input type="range" class="form-range personality-slider" min="1" max="10" value="${personalityData.affection || 7}" id="affection" name="affection">
                            <div class="d-flex justify-content-between">
                                <small>Reservada</small>
                                <small>Carinhosa</small>
                            </div>
                        </div>
                        <div class="mb-3 personality-trait">
                            <label for="humor" class="form-label">Nível de Humor</label>
                            <input type="range" class="form-range personality-slider" min="1" max="10" value="${personalityData.humor || 6}" id="humor" name="humor">
                            <div class="d-flex justify-content-between">
                                <small>Séria</small>
                                <small>Brincalhona</small>
                            </div>
                        </div>
                        <div class="mb-3 personality-trait">
                            <label for="chattiness" class="form-label">Comunicatividade</label>
                            <input type="range" class="form-range personality-slider" min="1" max="10" value="${personalityData.chattiness || 7}" id="chattiness" name="chattiness">
                            <div class="d-flex justify-content-between">
                                <small>Breve</small>
                                <small>Falante</small>
                            </div>
                        </div>
                        <div class="mb-3 personality-trait">
                            <label for="sensitivity" class="form-label">Sensibilidade</label>
                            <input type="range" class="form-range personality-slider" min="1" max="10" value="${personalityData.sensitivity || 6}" id="sensitivity" name="sensitivity">
                            <div class="d-flex justify-content-between">
                                <small>Durona</small>
                                <small>Sensível</small>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Profile Tab -->
                    <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                        <div class="mb-3">
                            <label for="bio" class="form-label">Biografia</label>
                            <textarea class="form-control" id="bio" name="bio" rows="4" placeholder="Escreva uma breve biografia para sua namorada virtual...">${personalityData.bio || ''}</textarea>
                        </div>
                        <div class="mb-3">
                            <label for="interests" class="form-label">Interesses</label>
                            <textarea class="form-control" id="interests-text" rows="3" placeholder="Digite interesses separados por vírgula...">${Array.isArray(personalityData.interests) ? personalityData.interests.join(', ') : ''}</textarea>
                            <input type="hidden" id="interests" name="interests" value="${JSON.stringify(personalityData.interests || [])}">
                            <small class="form-text text-muted">Separe os interesses por vírgula (ex: música, filmes, viagens)</small>
                        </div>
                    </div>
                    
                    <!-- Preferences Tab -->
                    <div class="tab-pane fade" id="preferences" role="tabpanel" aria-labelledby="preferences-tab">
                        <div class="mb-3">
                            <label for="likes" class="form-label">Do que ela gosta</label>
                            <textarea class="form-control" id="likes-text" rows="3" placeholder="Digite o que ela gosta separado por vírgula...">${Array.isArray(personalityData.likes) ? personalityData.likes.join(', ') : ''}</textarea>
                            <input type="hidden" id="likes" name="likes" value="${JSON.stringify(personalityData.likes || [])}">
                            <small class="form-text text-muted">Separe os itens por vírgula (ex: chocolate, praia, dançar)</small>
                        </div>
                        <div class="mb-3">
                            <label for="dislikes" class="form-label">Do que ela não gosta</label>
                            <textarea class="form-control" id="dislikes-text" rows="3" placeholder="Digite o que ela não gosta separado por vírgula...">${Array.isArray(personalityData.dislikes) ? personalityData.dislikes.join(', ') : ''}</textarea>
                            <input type="hidden" id="dislikes" name="dislikes" value="${JSON.stringify(personalityData.dislikes || [])}">
                            <small class="form-text text-muted">Separe os itens por vírgula (ex: mentiras, filme de terror, acordar cedo)</small>
                        </div>
                    </div>
                </div>
                
                <div class="alert alert-warning">
                    <i class="fas fa-info-circle"></i> Para gerenciar imagens de perfil, imagens de fundo e galeria, use a interface web no computador.
                </div>
                
                <button type="submit" class="btn btn-primary mt-3">Salvar Alterações</button>
            </form>
        `;
        
        settingsContent.innerHTML = formHtml;
        
        // Processar campos de array
        const processArrayField = function(fieldId) {
            const textField = document.getElementById(`${fieldId}-text`);
            const hiddenField = document.getElementById(fieldId);
            
            if (textField && hiddenField) {
                textField.addEventListener('change', function() {
                    const items = textField.value.split(',')
                        .map(item => item.trim())
                        .filter(item => item.length > 0);
                    hiddenField.value = JSON.stringify(items);
                });
            }
        };
        
        // Configurar campos de array
        processArrayField('interests');
        processArrayField('likes');
        processArrayField('dislikes');
        
        // Configurar envio do formulário
        const personalityForm = document.getElementById('personality-form');
        if (personalityForm) {
            personalityForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                // Disparar eventos de mudança para atualizar campos ocultos
                document.getElementById('interests-text').dispatchEvent(new Event('change'));
                document.getElementById('likes-text').dispatchEvent(new Event('change'));
                document.getElementById('dislikes-text').dispatchEvent(new Event('change'));
                
                const formData = new FormData(personalityForm);
                const personalityData = {};
                
                for (let [key, value] of formData.entries()) {
                    // Se a chave é um dos sliders numéricos ou idade, converter para int
                    if (['affection', 'humor', 'chattiness', 'sensitivity', 'age'].includes(key)) {
                        personalityData[key] = parseInt(value);
                    } 
                    // Se a chave é um dos campos de array, fazer parse do JSON
                    else if (['interests', 'likes', 'dislikes'].includes(key)) {
                        try {
                            personalityData[key] = JSON.parse(value);
                        } catch (e) {
                            personalityData[key] = [];
                        }
                    }
                    // Caso contrário, usar o valor string
                    else {
                        personalityData[key] = value;
                    }
                }
                
                // Verifica se estamos rodando no Capacitor (dispositivo móvel)
                const isCapacitorApp = window.Capacitor && window.Capacitor.isNative;
                
                if (isCapacitorApp) {
                    // Salva os dados localmente usando o PersonalityService
                    if (PersonalityService.savePersonality(personalityData)) {
                        console.log("Personalidade salva localmente com sucesso");
                        
                        // Atualiza a personalidade no escopo atual
                        window.personalityData = personalityData;
                        
                        // Atualiza a UI
                        updateUIWithPersonality();
                        
                        // Mostra feedback ao usuário
                        alert("Configurações salvas com sucesso no dispositivo!");
                    } else {
                        console.error("Erro ao salvar personalidade localmente");
                        alert("Erro ao salvar configurações. Por favor, tente novamente.");
                    }
                    
                    // Se tiver conexão com o servidor, tenta sincronizar também
                    if (serverURL) {
                        fetch(`${serverURL}/update_personality`, {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify(personalityData)
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.status === 'success') {
                                console.log("Personalidade sincronizada com o servidor");
                            }
                        })
                        .catch(error => {
                            console.error("Erro ao sincronizar personalidade com o servidor:", error);
                        });
                    }
                } else {
                    // Modo online - envia ao servidor
                    fetch(`${serverURL}/update_personality`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(personalityData)
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success') {
                            // Atualizar personalidade local
                            window.personalityData = personalityData;
                            
                            // Atualizar UI
                            updateUIWithPersonality();
                            
                            // Mostrar mensagem de sucesso
                            const alertElement = document.createElement('div');
                            alertElement.classList.add('alert', 'alert-success', 'mt-3');
                            alertElement.innerText = 'Configurações de personalidade atualizadas!';
                            personalityForm.appendChild(alertElement);
                            
                            // Remover o alerta após 3 segundos
                            setTimeout(() => {
                                alertElement.remove();
                            }, 3000);
                        }
                    })
                    .catch(error => {
                        console.error('Error updating personality:', error);
                    });
                }
            });
        }
        
        hideLoadingSpinner();
    }
    
    // Função para carregar o histórico do chat
    function loadChatHistory() {
        // Verificar se estamos rodando no Capacitor (dispositivo móvel)
        const isCapacitorApp = window.Capacitor && window.Capacitor.isNative;
        
        if (isCapacitorApp) {
            // Usar SQLite para carregar o histórico de conversas
            SQLiteService.getRecentConversations(50)
                .then(conversations => {
                    if (conversations && conversations.length > 0) {
                        console.log(`${conversations.length} conversas carregadas do SQLite`);
                        
                        // Limpar mensagens existentes
                        chatMessages.innerHTML = '';
                        
                        // Renderiza as conversas armazenadas localmente
                        conversations.forEach(entry => {
                            // Para cada conversa, adiciona mensagem ao chat
                            addMessageToChat(entry.message, entry.is_user === 1);
                        });
                    } else {
                        console.log("Nenhuma conversa encontrada no SQLite local");
                        // Adicionar mensagem de boas-vindas se não houver histórico
                        const personality = window.personalityData || PersonalityService.loadPersonality();
                        const botName = personality?.name || "Namorada Virtual";
                        addMessageToChat(`Oi! Eu sou ${botName}. Como você está hoje?`, false);
                    }
                })
                .catch(error => {
                    console.error("Erro ao carregar conversas do SQLite:", error);
                    
                    // Adicionar mensagem de boas-vindas em caso de erro
                    const personality = window.personalityData || PersonalityService.loadPersonality();
                    const botName = personality?.name || "Namorada Virtual";
                    addMessageToChat(`Oi! Eu sou ${botName}. Como você está hoje?`, false);
                });
        } else {
            // Fallback para navegador web - carrega do servidor se disponível
            if (serverURL) {
                fetch(`${serverURL}/get_chat_history`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.history && data.history.length > 0) {
                            // Limpar mensagens existentes
                            chatMessages.innerHTML = '';
                            
                            // Adicionar cada mensagem ao chat
                            data.history.forEach(item => {
                                addMessageToChat(item.message, item.user);
                            });
                        } else {
                            // Adicionar mensagem de boas-vindas se não houver histórico
                            addMessageToChat('Oi! Eu sou sua namorada virtual. Como você está hoje?', false);
                        }
                    })
                    .catch(error => {
                        console.error('Error loading chat history:', error);
                        addMessageToChat('Oi! Eu sou sua namorada virtual. Como você está hoje?', false);
                    });
            } else {
                // Sem conexão com servidor no navegador
                addMessageToChat('Oi! Eu sou sua namorada virtual. Como você está hoje?', false);
            }
        }
    }
    
    // Função para adicionar uma mensagem ao chat
    function addMessageToChat(message, isUser, imageUrl = null) {
        const messageElement = document.createElement('div');
        messageElement.classList.add('message', isUser ? 'user-message' : 'bot-message');
        
        // Adicionar imagem de perfil para mensagens da namorada virtual
        if (!isUser && personalityData && personalityData.profile_image) {
            const profileContainer = document.createElement('div');
            profileContainer.classList.add('profile-container');
            
            const profileImage = document.createElement('img');
            
            // Verificar se estamos em modo offline (Capacitor) ou online
            const isCapacitorApp = window.Capacitor && window.Capacitor.isNative;
            
            if (isCapacitorApp) {
                // Em desenvolvimento: em produção, precisaríamos armazenar a imagem no dispositivo
                // Para simplificar, usaremos um ícone embutido como fallback
                profileImage.src = 'img/app-icon.svg';
            } else if (serverURL) {
                profileImage.src = `${serverURL}/static/${personalityData.profile_image}`;
            } else {
                profileImage.src = 'img/app-icon.svg';
            }
            
            profileImage.alt = personalityData.name || 'Namorada Virtual';
            profileImage.classList.add('profile-image');
            
            const botName = document.createElement('div');
            botName.classList.add('bot-name');
            botName.innerText = personalityData.name || 'Namorada Virtual';
            
            profileContainer.appendChild(profileImage);
            profileContainer.appendChild(botName);
            
            const messageWrap = document.createElement('div');
            messageWrap.appendChild(profileContainer);
            messageWrap.appendChild(messageElement);
            
            chatMessages.appendChild(messageWrap);
        } else {
            chatMessages.appendChild(messageElement);
        }
        
        // Criar conteúdo de texto
        const textElement = document.createElement('div');
        textElement.classList.add('message-text');
        textElement.innerText = message;
        messageElement.appendChild(textElement);
        
        // Adicionar imagem se fornecida
        if (imageUrl) {
            const imageContainer = document.createElement('div');
            imageContainer.classList.add('message-image-container', 'mt-2');
            
            const image = document.createElement('img');
            
            // Verificar se estamos em modo offline (Capacitor) ou online
            const isCapacitorApp = window.Capacitor && window.Capacitor.isNative;
            
            if (isCapacitorApp) {
                // Em um aplicativo real, teríamos que armazenar as imagens localmente
                // ou usar o Filesystem API do Capacitor para acessar imagens salvas
                // Como simplificação, usaremos a imagem do ícone como fallback
                image.src = 'img/app-icon.svg';
            } else {
                // Se a URL começar com "http", usar como está. Caso contrário, adicionar o URL do servidor
                image.src = imageUrl.startsWith('http') ? imageUrl : `${serverURL}${imageUrl}`;
            }
            
            image.alt = 'Imagem compartilhada';
            image.classList.add('message-image', 'img-fluid', 'rounded');
            image.style.maxWidth = '200px';
            image.style.maxHeight = '200px';
            image.style.cursor = 'pointer';
            
            // Adicionar evento de clique para abrir a imagem em visualização maior
            image.addEventListener('click', function() {
                document.getElementById('modal-image').src = image.src;
                imageModal.show();
            });
            
            imageContainer.appendChild(image);
            messageElement.appendChild(imageContainer);
        }
        
        // Rolar para a mensagem mais recente
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    // Função para enviar uma mensagem
    function sendMessage() {
        const message = messageInput.value.trim();
        if (message) {
            // Adicionar mensagem do usuário ao chat
            addMessageToChat(message, true);
            
            // Limpar campo de entrada
            messageInput.value = '';
            
            // Enviar mensagem para o servidor
            fetch(`${serverURL}/send_message`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ message: message })
            })
            .then(response => response.json())
            .then(data => {
                // Adicionar resposta da namorada virtual ao chat (com imagem se presente)
                if (data.image_url) {
                    addMessageToChat(data.response, false, data.image_url);
                } else {
                    addMessageToChat(data.response, false);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                addMessageToChat('Desculpe, tive um problema processando sua mensagem.', false);
            });
        }
    }
    
    // No modo web, ainda precisamos destes event listeners
    // Nota: No modo Capacitor/móvel, eles são substituídos pelos listeners offline
    // Porém no modo web, ainda usamos os listeners do servidor
    const isCapacitorApp = window.Capacitor && window.Capacitor.isNative;
    if (!isCapacitorApp) {
        sendButton.addEventListener('click', sendMessage);
        
        messageInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });
        
        clearButton.addEventListener('click', function() {
            // Limpar interface do chat
            chatMessages.innerHTML = '';
            
            // Se temos conexão com servidor, limpar histórico lá também
            if (serverURL) {
                fetch(`${serverURL}/clear_chat`, {
                    method: 'POST'
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        addMessageToChat('O histórico do chat foi limpo. Como posso te ajudar hoje?', false);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    // Adicionar mensagem de limpo mesmo em caso de erro
                    addMessageToChat('O histórico do chat foi limpo. Como posso te ajudar hoje?', false);
                });
            } else {
                // Sem servidor, só mostrar a mensagem
                addMessageToChat('O histórico do chat foi limpo. Como posso te ajudar hoje?', false);
            }
        });
    }
    
    // Iniciar o aplicativo diretamente (modo offline)
    // A condição window.load já foi configurada para chamar initializeApp() após o carregamento
});