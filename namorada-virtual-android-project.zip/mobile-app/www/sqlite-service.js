/**
 * SQLite Service para o aplicativo móvel
 * Fornece funcionalidades para interagir com o banco de dados SQLite local
 */

const SQLiteService = (function() {
    // Variáveis privadas
    let _db = null;
    let _isInitialized = false;
    const _dbName = "namoradavirtual.db";
    
    // Verifica se estamos rodando em um ambiente Capacitor
    const isNative = window.Capacitor && window.Capacitor.isNative;
    
    /**
     * Inicializa o banco de dados SQLite
     * @returns {Promise} Promise que resolve quando o banco de dados é inicializado
     */
    async function init() {
        if (_isInitialized) {
            console.log("SQLite já inicializado");
            return Promise.resolve();
        }
        
        if (!isNative) {
            console.warn("SQLite não suportado no navegador web");
            return Promise.resolve();
        }
        
        try {
            console.log("Inicializando SQLite...");
            
            const { CapacitorSQLite } = window.Capacitor.Plugins;
            
            // Cria a conexão com o banco de dados
            await CapacitorSQLite.createConnection({
                database: _dbName,
                encrypted: false,
                mode: "no-encryption",
                version: 1
            });
            
            // Abre a conexão
            await CapacitorSQLite.open({
                database: _dbName
            });
            
            console.log("Banco de dados aberto com sucesso");
            
            // Cria as tabelas necessárias
            await _createTables();
            
            _isInitialized = true;
            console.log("SQLite inicializado com sucesso");
            
            return Promise.resolve();
        } catch (error) {
            console.error("Erro ao inicializar SQLite:", error);
            return Promise.reject(error);
        }
    }
    
    /**
     * Cria as tabelas necessárias no banco de dados
     * @returns {Promise} Promise que resolve quando as tabelas são criadas
     */
    async function _createTables() {
        try {
            const { CapacitorSQLite } = window.Capacitor.Plugins;
            
            // Tabela de informações aprendidas
            const createLearnedInfoTable = `
            CREATE TABLE IF NOT EXISTS learned_info (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key TEXT NOT NULL,
                value TEXT NOT NULL,
                context TEXT,
                confidence REAL DEFAULT 0.7,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                times_referenced INTEGER DEFAULT 0
            );`;
            
            // Tabela de entradas de conversa
            const createConversationEntryTable = `
            CREATE TABLE IF NOT EXISTS conversation_entry (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                message TEXT NOT NULL,
                is_user INTEGER DEFAULT 1,
                sentiment REAL,
                timestamp TEXT DEFAULT CURRENT_TIMESTAMP
            );`;
            
            // Tabela de tags de conversa
            const createConversationTagTable = `
            CREATE TABLE IF NOT EXISTS conversation_tag (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tag TEXT NOT NULL UNIQUE,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );`;
            
            // Tabela de relacionamento entre entradas e tags
            const createEntryTagsTable = `
            CREATE TABLE IF NOT EXISTS conversation_entry_tags (
                conversation_entry_id INTEGER,
                conversation_tag_id INTEGER,
                PRIMARY KEY (conversation_entry_id, conversation_tag_id),
                FOREIGN KEY (conversation_entry_id) REFERENCES conversation_entry(id) ON DELETE CASCADE,
                FOREIGN KEY (conversation_tag_id) REFERENCES conversation_tag(id) ON DELETE CASCADE
            );`;
            
            // Tabela de relacionamento entre entradas e informações aprendidas
            const createEntryLearningsTable = `
            CREATE TABLE IF NOT EXISTS conversation_entry_learnings (
                conversation_entry_id INTEGER,
                learned_info_id INTEGER,
                PRIMARY KEY (conversation_entry_id, learned_info_id),
                FOREIGN KEY (conversation_entry_id) REFERENCES conversation_entry(id) ON DELETE CASCADE,
                FOREIGN KEY (learned_info_id) REFERENCES learned_info(id) ON DELETE CASCADE
            );`;
            
            // Executa as queries para criar as tabelas
            await CapacitorSQLite.executeSet({
                database: _dbName,
                statements: [
                    createLearnedInfoTable,
                    createConversationEntryTable,
                    createConversationTagTable,
                    createEntryTagsTable,
                    createEntryLearningsTable
                ]
            });
            
            console.log("Tabelas criadas com sucesso");
            return Promise.resolve();
        } catch (error) {
            console.error("Erro ao criar tabelas:", error);
            return Promise.reject(error);
        }
    }
    
    /**
     * Executa uma query SQL
     * @param {string} query - A query SQL a ser executada
     * @param {Array} params - Parâmetros para a query
     * @returns {Promise} Promise que resolve com o resultado da query
     */
    async function executeQuery(query, params = []) {
        if (!isNative || !_isInitialized) {
            console.warn("SQLite não disponível ou não inicializado");
            return Promise.resolve({ values: [] });
        }
        
        try {
            const { CapacitorSQLite } = window.Capacitor.Plugins;
            
            const result = await CapacitorSQLite.query({
                database: _dbName,
                statement: query,
                values: params
            });
            
            return Promise.resolve(result);
        } catch (error) {
            console.error("Erro ao executar query:", error);
            return Promise.reject(error);
        }
    }
    
    /**
     * Salva uma informação aprendida no banco de dados
     * @param {string} key - Chave/categoria da informação
     * @param {string} value - Valor da informação
     * @param {string} context - Contexto onde a informação foi obtida
     * @param {number} confidence - Nível de confiança (0-1)
     * @returns {Promise} Promise que resolve com o resultado da operação
     */
    async function saveLearnedInfo(key, value, context = null, confidence = 0.7) {
        if (!isNative || !_isInitialized) {
            console.warn("SQLite não disponível ou não inicializado");
            return Promise.resolve();
        }
        
        try {
            // Verifica se já existe uma informação com a mesma chave
            const checkQuery = "SELECT id, confidence FROM learned_info WHERE key = ?";
            const existingInfo = await executeQuery(checkQuery, [key]);
            
            if (existingInfo.values && existingInfo.values.length > 0) {
                // Se já existe e a nova confiança é maior, atualiza
                if (confidence > existingInfo.values[0].confidence) {
                    const updateQuery = `
                    UPDATE learned_info 
                    SET value = ?, context = ?, confidence = ?, updated_at = CURRENT_TIMESTAMP 
                    WHERE id = ?
                    `;
                    
                    await executeQuery(updateQuery, [
                        value, 
                        context, 
                        confidence, 
                        existingInfo.values[0].id
                    ]);
                    
                    console.log(`Informação atualizada: ${key} = ${value}`);
                } else {
                    console.log(`Informação existente mantida com confiança maior: ${key}`);
                }
            } else {
                // Se não existe, insere nova informação
                const insertQuery = `
                INSERT INTO learned_info (key, value, context, confidence) 
                VALUES (?, ?, ?, ?)
                `;
                
                await executeQuery(insertQuery, [key, value, context, confidence]);
                console.log(`Nova informação aprendida: ${key} = ${value}`);
            }
            
            return Promise.resolve();
        } catch (error) {
            console.error("Erro ao salvar informação aprendida:", error);
            return Promise.reject(error);
        }
    }
    
    /**
     * Busca uma informação aprendida por chave
     * @param {string} key - Chave da informação a ser buscada
     * @returns {Promise} Promise que resolve com o valor da informação
     */
    async function getLearnedInfoByKey(key) {
        if (!isNative || !_isInitialized) {
            console.warn("SQLite não disponível ou não inicializado");
            return Promise.resolve(null);
        }
        
        try {
            const query = "SELECT * FROM learned_info WHERE key = ? ORDER BY confidence DESC LIMIT 1";
            const result = await executeQuery(query, [key]);
            
            if (result.values && result.values.length > 0) {
                // Incrementa o contador de referências
                const updateQuery = "UPDATE learned_info SET times_referenced = times_referenced + 1 WHERE id = ?";
                await executeQuery(updateQuery, [result.values[0].id]);
                
                return Promise.resolve(result.values[0]);
            } else {
                return Promise.resolve(null);
            }
        } catch (error) {
            console.error("Erro ao buscar informação por chave:", error);
            return Promise.reject(error);
        }
    }
    
    /**
     * Busca todas as informações aprendidas
     * @returns {Promise} Promise que resolve com um array de informações
     */
    async function getAllLearnedInfo() {
        if (!isNative || !_isInitialized) {
            console.warn("SQLite não disponível ou não inicializado");
            return Promise.resolve([]);
        }
        
        try {
            const query = "SELECT * FROM learned_info ORDER BY updated_at DESC";
            const result = await executeQuery(query);
            
            return Promise.resolve(result.values || []);
        } catch (error) {
            console.error("Erro ao buscar todas as informações:", error);
            return Promise.reject(error);
        }
    }
    
    /**
     * Salva uma entrada de conversa
     * @param {string} message - Mensagem da conversa
     * @param {boolean} isUser - Se a mensagem é do usuário (true) ou do bot (false)
     * @param {number} sentiment - Sentimento da mensagem (-1 a 1)
     * @returns {Promise} Promise que resolve com o ID da entrada
     */
    async function saveConversationEntry(message, isUser = true, sentiment = null) {
        if (!isNative || !_isInitialized) {
            console.warn("SQLite não disponível ou não inicializado");
            return Promise.resolve(null);
        }
        
        try {
            const query = `
            INSERT INTO conversation_entry (message, is_user, sentiment) 
            VALUES (?, ?, ?)
            `;
            
            const result = await executeQuery(query, [
                message, 
                isUser ? 1 : 0, 
                sentiment
            ]);
            
            console.log(`Entrada de conversa salva, ID: ${result.lastId}`);
            return Promise.resolve(result.lastId);
        } catch (error) {
            console.error("Erro ao salvar entrada de conversa:", error);
            return Promise.reject(error);
        }
    }
    
    /**
     * Obtém as entradas de conversa mais recentes
     * @param {number} limit - Número máximo de entradas a retornar
     * @returns {Promise} Promise que resolve com um array de entradas
     */
    async function getRecentConversations(limit = 50) {
        if (!isNative || !_isInitialized) {
            console.warn("SQLite não disponível ou não inicializado");
            return Promise.resolve([]);
        }
        
        try {
            const query = `
            SELECT * FROM conversation_entry 
            ORDER BY timestamp DESC 
            LIMIT ?
            `;
            
            const result = await executeQuery(query, [limit]);
            
            // Inverte para ordem cronológica
            const conversations = result.values || [];
            return Promise.resolve(conversations.reverse());
        } catch (error) {
            console.error("Erro ao buscar conversas recentes:", error);
            return Promise.reject(error);
        }
    }
    
    /**
     * Limpa todo o histórico de conversas
     * @returns {Promise} Promise que resolve quando a operação é concluída
     */
    async function clearConversationHistory() {
        if (!isNative || !_isInitialized) {
            console.warn("SQLite não disponível ou não inicializado");
            return Promise.resolve();
        }
        
        try {
            // Deleta todas as entradas de conversa
            await executeQuery("DELETE FROM conversation_entry");
            console.log("Histórico de conversas limpo com sucesso");
            return Promise.resolve();
        } catch (error) {
            console.error("Erro ao limpar histórico de conversas:", error);
            return Promise.reject(error);
        }
    }
    
    // Interface pública
    return {
        init,
        executeQuery,
        saveLearnedInfo,
        getLearnedInfoByKey,
        getAllLearnedInfo,
        saveConversationEntry,
        getRecentConversations,
        clearConversationHistory
    };
})();

// Exporta para uso global
window.SQLiteService = SQLiteService;